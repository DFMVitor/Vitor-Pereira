package dao;

import model.Aluno;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AlunoDAO {

    public void inserir(Aluno a) throws SQLException {
        String sql = "INSERT INTO alunos (rm, aluno, rg, telefone, email) VALUES (?,?,?,?,?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, a.getRm());
            pst.setString(2, a.getAluno());
            pst.setString(3, a.getRg());
            pst.setLong(4, a.getTelefone());
            pst.setString(5, a.getEmail());
            pst.executeUpdate();
        }
    }

    public List<Aluno> listar() throws SQLException {
        List<Aluno> lista = new ArrayList<>();
        String sql = "SELECT rm, aluno, rg, telefone, email FROM alunos";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                Aluno a = new Aluno();
                a.setRm(rs.getInt("rm"));
                a.setAluno(rs.getString("aluno"));
                a.setRg(rs.getString("rg"));
                a.setTelefone(rs.getLong("telefone"));
                a.setEmail(rs.getString("email"));
                lista.add(a);
            }
        }
        return lista;
    }
}
