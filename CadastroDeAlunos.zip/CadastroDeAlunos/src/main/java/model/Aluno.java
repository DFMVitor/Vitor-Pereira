package model;

public class Aluno {
    private int rm;
    private String aluno;
    private String rg;
    private long telefone;
    private String email;

    // Construtor vazio
    public Aluno() {}

    // Construtor com parâmetros
    public Aluno(int rm, String aluno, String rg, long telefone, String email) {
        this.rm = rm;
        this.aluno = aluno;
        this.rg = rg;
        this.telefone = telefone;
        this.email = email;
    }

    // Getters e Setters
    public int getRm() {
        return rm;
    }

    public void setRm(int rm) {
        this.rm = rm;
    }

    public String getAluno() {
        return aluno;
    }

    public void setAluno(String aluno) {
        this.aluno = aluno;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public long getTelefone() {
        return telefone;
    }

    public void setTelefone(long telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}